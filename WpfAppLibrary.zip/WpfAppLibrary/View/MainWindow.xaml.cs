﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppLibrary.Model;
using WpfAppLibrary.ViewModel;

namespace WpfAppLibrary
{
    /// <summary>
     /// View — только UI
     /// </summary>
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _vm;

        public MainWindow()
        {
            InitializeComponent();
            _vm = new MainViewModel();
            BooksList.ItemsSource = _vm.Books;
        }

        private void Issue_Click(object sender, RoutedEventArgs e)
        {
            string result = _vm.Issue(IssueIdBox.Text.Trim());
            ShowResult(result, "Выдана");
            IssueIdBox.Clear();
        }

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            string result = _vm.Return(IssueIdBox.Text.Trim());
            ShowResult(result, "Возвращена");
            IssueIdBox.Clear();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            string result = _vm.Add(
                AddIdBox.Text.Trim(),
                AddAuthorBox.Text.Trim(),
                AddTitleBox.Text.Trim(),
                AddAvailableBox.IsChecked == true);

            ShowResult(result, "Книга добавлена");

            AddIdBox.Clear();
            AddAuthorBox.Clear();
            AddTitleBox.Clear();
            AddAvailableBox.IsChecked = true;
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            string result = _vm.Remove(RemoveIdBox.Text.Trim());
            ShowResult(result, "Удалена");
            RemoveIdBox.Clear();
        }

        private void ShowResult(string message, string successPrefix)
        {
            if (message.StartsWith(successPrefix))
                MessageBox.Show(message, "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            else
                MessageBox.Show(message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
