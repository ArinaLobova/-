﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using WpfAppLibrary.Model;

namespace WpfAppLibrary.ViewModel
{
    /// <summary>
    /// ViewModel: хранит модель, сервис файла и коллекцию для UI.
    /// </summary>
    public class MainViewModel
    {
        private readonly LibraryModel _model;
        private readonly FileService _fileService;
        public ObservableCollection<Book> Books { get; private set; }
        public MainViewModel()
        {
            _model = new LibraryModel();
            string filePath = Path.Combine("..", "..", "Data", "ListBooks.txt");
            _fileService = new FileService(filePath);
            List<Book> loaded = _fileService.Load();
            _model.SetBooks(loaded);
            Books = new ObservableCollection<Book>(_model.Books.Values);
        }
        public string Issue(string id)
        {
            string result = _model.IssueBook(id);
            SyncBooks();
            return result;
        }

        public string Return(string id)
        {
            string result = _model.ReturnBook(id);
            SyncBooks();
            return result;
        }

        public string Add(string id, string author, string title, bool isAvailable)
        {
            string result = _model.AddBook(id, author, title, isAvailable);
            SyncBooks();
            return result;
        }

        public string Remove(string id)
        {
            string result = _model.RemoveBook(id);
            SyncBooks();
            return result;
        }

        public string SaveToFile()
        {
            _fileService.Save(_model.Books.Values);
            return "Список сохранён в файл.";
        }

        private void SyncBooks()
        {
            Books.Clear();
            foreach (var b in _model.Books.Values)
            {
                Books.Add(b);
            }
        }
    }
}
