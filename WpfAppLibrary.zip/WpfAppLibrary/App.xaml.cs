﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using WpfAppLibrary.ViewModel;

namespace WpfAppLibrary
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        private MainViewModel _viewModel;

       
        protected override void OnExit(ExitEventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.SaveToFile();
            }

            base.OnExit(e);
        }
    }
}
