﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppLibrary.Model
{
    public class LibraryModel
    {
        private readonly Dictionary<string, Book> _books = new Dictionary<string, Book>();

        public void SetBooks(IEnumerable<Book> books)
        {
            _books.Clear();
            foreach (var book in books)
            {
                _books[book.Id] = book;
            }
        }

        public IReadOnlyDictionary<string, Book> Books => _books;

        /// <summary>Выдать книгу. Возвращает текст-результат.</summary>
        public string IssueBook(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return "Номер книги не указан.";

            if (!_books.TryGetValue(id, out var book))
                return $"Книга с номером {id} не найдена.";

            if (!book.IsAvailable)
                return $"Книга \"{book.Title}\" уже выдана.";

            book.IsAvailable = false;
            return $"Выдана: '{book.Title}'";
        }

        /// <summary>Вернуть книгу.</summary>
        public string ReturnBook(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return "Номер книги не указан.";

            if (!_books.TryGetValue(id, out var book))
                return $"Книга с номером {id} не найдена.";
            if (book.IsAvailable)
                return $"Книга '{book.Title}' и так в наличии";

            book.IsAvailable = true;
            return $"Возвращена: \"{book.Title}\"";
        }

        /// <summary>Добавить книгу.</summary>
        public string AddBook(string id, string author, string title, bool isAvailable)
        {
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(author) || string.IsNullOrWhiteSpace(title))
                return "Все поля должны быть заполнены.";

            if (_books.ContainsKey(id))
                return $"Книга с номером {id} уже существует.";

            _books[id] = new Book(id, title, author, isAvailable);
            return $"Книга добавлена: {id} {author} \"{title}\", в наличии: {(isAvailable ? "да" : "нет")}";
        }

        /// <summary>Удалить книгу.</summary>
        public string RemoveBook(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return "Номер книги не указан.";

            if (!_books.TryGetValue(id, out var book))
                return $"Книга с номером {id} не найдена.";

            _books.Remove(id);
            return $"Удалена: {book.Author} \"{book.Title}\"";
        }
    }

}
