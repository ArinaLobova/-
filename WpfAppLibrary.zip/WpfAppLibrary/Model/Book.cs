﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppLibrary.Model
{
    /// <summary>
    /// Класс для иннициализации объекта Книга
    /// </summary>
    public class Book
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public bool IsAvailable { get; set; }

        public Book(string id, string title, string author, bool isAvailable)
        {
            Id = id;
            Title = title;
            Author = author;
            IsAvailable = isAvailable;
        }

        public override string ToString()
        {
            string status = IsAvailable ? "в наличии" : "выдана";
            return $"{Id} | {Author} — \"{Title}\" ({status})";
        }
    }
}
