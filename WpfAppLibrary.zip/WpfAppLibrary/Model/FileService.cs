﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppLibrary.Model
{
    /// <summary>
    /// Чтение и запись книг в текстовый файл.
    /// </summary>
    public class FileService
    {
        private readonly string _path;
        public FileService(string path)
        {
            _path = path;
        }
        public List<Book> Load()
        {
            var result = new List<Book>();
            if(!File.Exists(_path)) return result;

            foreach (string line in File.ReadAllLines(_path))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                string[] path = line.Split('|');
                if(path.Length != 4) continue;
                string id = path[0];
                string title = path[1];
                string authoe = path[2];
                bool isAvailable = path[3] == "да";
                result.Add(new Book(id, title, authoe, isAvailable));
            }
            return result;
        }

        public void Save(IEnumerable<Book> books)
        {
            string text = "";
            foreach (var book in books)
            {
                text += $"{book.Id}|{book.Title}|{book.Author}|{(book.IsAvailable ? "да" : "нет")}\n";
            }
            File.WriteAllText(_path, text);
        }
    }
}
